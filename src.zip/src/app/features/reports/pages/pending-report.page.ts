import { Component } from '@angular/core';

@Component({
  standalone: true,
  selector: 'app-pending-report',
  template: `
    <h2 class="text-xl font-semibold text-surface-900 dark:text-surface-0 mb-4">Reporte de Pendientes</h2>
    <p class="text-surface-700 dark:text-surface-200">Contenido base…</p>
  `
})
export class PendingReportPage {}
