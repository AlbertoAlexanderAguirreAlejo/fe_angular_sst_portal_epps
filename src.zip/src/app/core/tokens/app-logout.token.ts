import { InjectionToken } from '@angular/core';

export const APP_LOGOUT = new InjectionToken<() => void>('APP_LOGOUT');
