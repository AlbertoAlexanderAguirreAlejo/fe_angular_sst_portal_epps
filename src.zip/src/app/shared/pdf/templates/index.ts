/* src/app/shared/pdf/templates/index.ts */
export * from './base.template';
export * from './delivery-epp.template';
