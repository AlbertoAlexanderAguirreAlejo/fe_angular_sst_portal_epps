export * from './templates/base.template';
