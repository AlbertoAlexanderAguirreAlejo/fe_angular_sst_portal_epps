export const environment = {
  production: true,
  apiUrl: 'https://www.agroparamonga.com/bkisiWeb/api/v1',
  appName: 'portal_epps'
};
